/**
 * File is automatically generated, Please do not modify
 * 数据表通用函数
 */
module game_config {
	var reg:RegExp = new RegExp("\\\\n", "g");

	export function replace(str:string):string {
		return str.replace(reg, "\n");
	}

}