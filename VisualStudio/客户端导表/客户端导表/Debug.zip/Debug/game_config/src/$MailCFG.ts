/**
* File is automatically generated, Please do not modify
* 邮件表
*/
module game_config {
export class $MailCFG {

    // ID
    public ID:number;
    // 发件人
    public From:string;
    // 邮件标题
    public Title:string;
    // 邮件内容
    public Content:string;

	/**
	 * 初始化数据
	 */
	public initData():void {
	}

	/**
	 * 读取txt文件填充数据, 返回配置ID
	 */
	public fillData(row:Array<string>):any {
		var filedArr:Array<string>;

        this.ID = +row[0];
        this.From = row[1];
        this.Title = row[2];
        this.Content = row[3];
    }
}
}