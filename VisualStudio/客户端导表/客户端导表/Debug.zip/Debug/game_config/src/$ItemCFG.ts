/**
* File is automatically generated, Please do not modify
* 物品表
*/
module game_config {
export class $ItemCFG {

    // 编号
    public ID:number;
    // 名称
    public Name:string;
    // 图标
    public Icon:string;
    // 掉落模型ID
    public DropIcon:string;
    // 职业限制
    public Job:number;
    // 转生等级限制
    public LvR:number;
    // 前置等级最低限制
    public BeforeLV:number;
    // 前置等级最高限制
    public BeforeLVMax:number;
    // 等级最低限制
    public Lv:number;
    // 等级最高限制
    public LvMax:number;
    // 转生最低限制
    public ZhuanMin:number;
    // 转生最高限制
    public ZhuanMax:number;
    // 等阶
    public Rank:number;
    // 转生等级限制
    public LvRMax:number;
    // 觉醒等级限制
    public AwakenLv:number;
    // 开服天数
    public Day:number;
    // 翅膀等级
    public WingLv:number;
    // 物品品质
    public Quality:number;
    // 物品特效
    public ItemEffectID:number;
    // 是否显示追光
    public IsShowLight:number;
    // X天以后不显示追光
    public NoLightDate:number;
    // 是否恭喜获得
    public GetShow:boolean;
    // 物品类别1
    public Type1:number;
    // 物品类别2
    public Type2:number;
    // 物品类别3
    public Type3:number;
    // 物品类别4
    public Type4:number;
    // 显示类型
    public ShowType:string;
    // 排序
    public sort:number;
    // 所需性别
    public Gender:number;
    // 出售价格
    public Price:number;
    // 叠加上限
    public Stack:number;
    // 是否可销毁
    public CanDestroy:number;
    // 是否可使用
    public UseType:number;
    // 是否可连续使用
    public ContinuousUse:number;
    // 是否可拍卖
    public CanAuction:number;
    // 是否可求购
    public CanNeedBuy:number;
    // 上架是否公告
    public IsSellNotice:boolean;
    // 作用类别
    public FuncType:number;
    // 使用限制时间
    public LimitTime:number;
    // 是否可升级
    public CanLvUp:number;
    // 是否记录
    public CanRecord:number;
    // 极品属性
    public Unusual:number;
    // 组
    public team:number;
    // 回收id
    public RecoverID:number;
    // 装备属性id
    public EquipID:number;
    // 帮会装备积分
    public donate:number;
    // 回收帮会数值
    public Treasure:number;
    // 是否可放入仓库
    public CanStorage:boolean;
    // 强化最高星级
    public IntensifyLvMax:number;
    // 极致强化最高等级
    public AceIntensifyLvMax:number;
    // 精炼最高星级
    public RefineLvMax:number;
    // CD类别
    public CDType:number;
    // 公共CD
    public CDPub:number;
    // CD时间
    public CD:number;
    // 是否推送
    public CanPush:number;
    // 重复推送
    public PushType:number;
    // 推送是否自动穿戴/使用
    public CanDress:number;
    // 是否公告
    public CanShow:number;
    // 公告天数
    public DayLimit:number;
    // 掉落展示优先级
    public DropShowSort:number;
    // 掉落记录是否置顶
    public IsTop:boolean;
    // 物品背包闪烁
    public IsShowUse:boolean;
    // 播放特效
    public PlayUseEffect:string;
    // 附加功能ID
    public Funcid:number;
    // 功能参数
    public Funcparams:Array<number>;
    // 使用提示
    public UseNotice:number;
    // 客户端功能ID
    public CFuncID:number;
    // 客户端功能参数
    public CFuncParam:Array<string>;
    // 是否可放入快捷栏
    public CanShortcut:boolean;
    // 评分值
    public Score:number;
    // 套装ID
    public SuitID:Array<number>;
    // 描述
    public Desc:string;
    // 掉落说明
    public DropDesc:string;
    // 公告ID
    public noticeID:number;
    // 系统获得提示是否显示图标
    public IsShowIcon:boolean;
    // 负重值
    public RelicWeight:number;
    // 遗物星级
    public RelicStar:number;
    // 遗物职业优先
    public RelicJobPush:number;
    // 获得途径ID
    public GatWayID:Array<number>;
    // 是否显示获取途径
    public ShowGatWay:boolean;
    // 展示特效
    public ShowEffect:number;
    // 图标特效
    public IconEffect:number;
    // 挖宝稀有弹窗
    public RareMine:number;
    // 挖宝记录置顶优先级
    public MineSort:number;
    // 动画特效ID
    public MovieID:number;
    // 动画下面显示文本翻译ID
    public MovieDesID:number;

	/**
	 * 初始化数据
	 */
	public initData():void {
	}

	/**
	 * 读取txt文件填充数据, 返回配置ID
	 */
	public fillData(row:Array<string>):any {
		var filedArr:Array<string>;

        this.ID = +row[0];
        this.Name = row[1];
        this.Icon = row[2];
        this.DropIcon = row[3];
        this.Job = +row[4];
        this.LvR = +row[5];
        this.BeforeLV = +row[6];
        this.BeforeLVMax = +row[7];
        this.Lv = +row[8];
        this.LvMax = +row[9];
        this.ZhuanMin = +row[10];
        this.ZhuanMax = +row[11];
        this.Rank = +row[12];
        this.LvRMax = +row[13];
        this.AwakenLv = +row[14];
        this.Day = +row[15];
        this.WingLv = +row[16];
        this.Quality = +row[17];
        this.ItemEffectID = +row[18];
        this.IsShowLight = +row[19];
        this.NoLightDate = +row[20];
        this.GetShow = row[21] == "1" ? true : false;
        this.Type1 = +row[22];
        this.Type2 = +row[23];
        this.Type3 = +row[24];
        this.Type4 = +row[25];
        this.ShowType = row[26];
        this.sort = +row[27];
        this.Gender = +row[28];
        this.Price = +row[29];
        this.Stack = +row[30];
        this.CanDestroy = +row[31];
        this.UseType = +row[32];
        this.ContinuousUse = +row[33];
        this.CanAuction = +row[34];
        this.CanNeedBuy = +row[35];
        this.IsSellNotice = row[36] == "1" ? true : false;
        this.FuncType = +row[37];
        this.LimitTime = +row[38];
        this.CanLvUp = +row[39];
        this.CanRecord = +row[40];
        this.Unusual = +row[41];
        this.team = +row[42];
        this.RecoverID = +row[43];
        this.EquipID = +row[44];
        this.donate = +row[45];
        this.Treasure = +row[46];
        this.CanStorage = row[47] == "1" ? true : false;
        this.IntensifyLvMax = +row[48];
        this.AceIntensifyLvMax = +row[49];
        this.RefineLvMax = +row[50];
        this.CDType = +row[51];
        this.CDPub = +row[52];
        this.CD = +row[53];
        this.CanPush = +row[54];
        this.PushType = +row[55];
        this.CanDress = +row[56];
        this.CanShow = +row[57];
        this.DayLimit = +row[58];
        this.DropShowSort = +row[59];
        this.IsTop = row[60] == "1" ? true : false;
        this.IsShowUse = row[61] == "1" ? true : false;
        this.PlayUseEffect = row[62];
        this.Funcid = +row[63];
        if (row[64] == "") {
            this.Funcparams = new Array<number>();
        } else {
            filedArr = row[64].split(',');
            this.Funcparams = new Array<number>()
            for (var i = 0; i < filedArr.length; i++) {
                this.Funcparams[64] = +filedArr[64];
            }
        }
        this.UseNotice = +row[65];
        this.CFuncID = +row[66];
        if (row[67] == "") {
            this.CFuncParam = new Array<string>();
        } else {
            filedArr = row[67].split(',');
            this.CFuncParam = new Array<string>()
            for (var i = 0; i < filedArr.length; i++) {
                this.CFuncParam[i] = filedArr[i];
            }
        }
        this.CanShortcut = row[68] == "1" ? true : false;
        this.Score = +row[69];
        if (row[73] == "") {
            this.SuitID = new Array<number>();
        } else {
            filedArr = row[73].split(',');
            this.SuitID = new Array<number>()
            for (var i = 0; i < filedArr.length; i++) {
                this.SuitID[73] = +filedArr[73];
            }
        }
        this.Desc = row[74];
        this.DropDesc = row[75];
        this.noticeID = +row[76];
        this.IsShowIcon = row[77] == "1" ? true : false;
        this.RelicWeight = +row[78];
        this.RelicStar = +row[79];
        this.RelicJobPush = +row[80];
        if (row[81] == "") {
            this.GatWayID = new Array<number>();
        } else {
            filedArr = row[81].split(',');
            this.GatWayID = new Array<number>()
            for (var i = 0; i < filedArr.length; i++) {
                this.GatWayID[81] = +filedArr[81];
            }
        }
        this.ShowGatWay = row[82] == "1" ? true : false;
        this.ShowEffect = +row[83];
        this.IconEffect = +row[84];
        this.RareMine = +row[85];
        this.MineSort = +row[86];
        this.MovieID = +row[87];
        this.MovieDesID = +row[88];
    }
}
}